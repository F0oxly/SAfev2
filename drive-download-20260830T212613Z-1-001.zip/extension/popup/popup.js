/**
 * SafeWeb - Popup Controller
 * Gerenciamento de eventos, interface de usuário e integração com o background worker
 */

import { SitesStorage } from '../storage/sites-storage.js';
import { HistoryStorage } from '../storage/history-storage.js';
import { SecurityAnalyzer } from '../services/security-analyzer.js';
import { ApiClient } from '../services/api-client.js';

// Elementos do DOM
const DOM = {
  tabButtons: document.querySelectorAll('.tab-btn'),
  tabContents: document.querySelectorAll('.tab-content'),
  sitesContainer: document.getElementById('sites-container'),
  historyContainer: document.getElementById('history-container'),
  statTotal: document.getElementById('stat-total'),
  statOnline: document.getElementById('stat-online'),
  statOffline: document.getElementById('stat-offline'),
  backendIndicator: document.getElementById('backend-status-indicator'),
  btnRefreshAll: document.getElementById('btn-refresh-all'),
  btnClearHistory: document.getElementById('btn-clear-history'),
  inputSiteUrl: document.getElementById('input-site-url'),
  inputSiteAlias: document.getElementById('input-site-alias'),
  btnSaveSite: document.getElementById('btn-save-site'),
  addSecurityPreview: document.getElementById('add-security-preview'),
  previewRiskBadge: document.getElementById('preview-risk-badge'),
  previewRiskReasons: document.getElementById('preview-risk-reasons'),
  inputScanUrl: document.getElementById('input-scan-url'),
  btnRunScan: document.getElementById('btn-run-scan'),
  scannerResultBox: document.getElementById('scanner-result-box'),
  siteModal: document.getElementById('site-modal'),
  modalSiteTitle: document.getElementById('modal-site-title'),
  modalSiteBody: document.getElementById('modal-site-body'),
  btnCloseModal: document.getElementById('btn-close-modal'),
  toast: document.getElementById('toast')
};

// Inicialização
document.addEventListener('DOMContentLoaded', async () => {
  setupTabs();
  setupEventListeners();
  await checkBackendStatus();
  await renderDashboard();
  await renderHistory();
});

/**
 * Configuração das Abas
 */
function setupTabs() {
  DOM.tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-tab');

      DOM.tabButtons.forEach(b => b.classList.remove('active'));
      DOM.tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetContent = document.getElementById(targetId);
      if (targetContent) {
        targetContent.classList.add('active');
      }

      if (targetId === 'tab-dashboard') renderDashboard();
      if (targetId === 'tab-history') renderHistory();
    });
  });
}

/**
 * Listeners de Eventos Principais
 */
function setupEventListeners() {
  // Atualizar todos os sites
  DOM.btnRefreshAll.addEventListener('click', async () => {
    showToast('Atualizando status dos sites...');
    DOM.btnRefreshAll.classList.add('rotating');
    try {
      await chrome.runtime.sendMessage({ action: 'CHECK_ALL_SITES' });
      await renderDashboard();
      await renderHistory();
      showToast('Verificação concluída!');
    } catch (err) {
      showToast('Erro ao atualizar: ' + err.message);
    } finally {
      DOM.btnRefreshAll.classList.remove('rotating');
    }
  });

  // Digitação da URL no cadastro (Live Heuristic Preview)
  let typingTimer;
  DOM.inputSiteUrl.addEventListener('input', () => {
    clearTimeout(typingTimer);
    const url = DOM.inputSiteUrl.value.trim();
    if (!url) {
      DOM.addSecurityPreview.style.display = 'none';
      return;
    }
    typingTimer = setTimeout(() => {
      runLivePreview(url);
    }, 250);
  });

  // Salvar novo site
  DOM.btnSaveSite.addEventListener('click', async () => {
    await handleAddSite();
  });

  // Limpar histórico
  DOM.btnClearHistory.addEventListener('click', async () => {
    if (confirm('Deseja realmente limpar todo o histórico de ocorrências?')) {
      await HistoryStorage.clear();
      await renderHistory();
      showToast('Histórico limpo com sucesso.');
    }
  });

  // Scanner de URL
  DOM.btnRunScan.addEventListener('click', () => {
    const url = DOM.inputScanUrl.value.trim();
    if (!url) {
      showToast('Por favor, informe uma URL para análise.');
      return;
    }
    runFullScan(url);
  });

  // Fechar Modal
  DOM.btnCloseModal.addEventListener('click', () => {
    DOM.siteModal.classList.remove('show');
  });

  DOM.siteModal.addEventListener('click', (e) => {
    if (e.target === DOM.siteModal) {
      DOM.siteModal.classList.remove('show');
    }
  });
}

/**
 * Verifica se o backend Node.js está respondendo
 */
async function checkBackendStatus() {
  const isAvailable = await ApiClient.isBackendAvailable();
  if (isAvailable) {
    DOM.backendIndicator.textContent = 'Backend Conectado (Node.js)';
    DOM.backendIndicator.style.color = '#a7f3d0';
  } else {
    DOM.backendIndicator.textContent = 'Modo Autônomo Local';
    DOM.backendIndicator.style.color = 'rgba(255, 255, 255, 0.8)';
  }
}

/**
 * Executa análise heurística em tempo real durante digitação
 */
function runLivePreview(url) {
  const analysis = SecurityAnalyzer.analyze(url);
  DOM.addSecurityPreview.style.display = 'flex';

  DOM.previewRiskBadge.textContent = analysis.label;
  DOM.previewRiskBadge.className = `badge badge-risk-${analysis.level}`;

  DOM.previewRiskReasons.innerHTML = '';
  analysis.reasons.forEach(r => {
    const li = document.createElement('li');
    li.textContent = r;
    DOM.previewRiskReasons.appendChild(li);
  });
}

/**
 * Adiciona novo site monitorado
 */
async function handleAddSite() {
  const rawUrl = DOM.inputSiteUrl.value.trim();
  const alias = DOM.inputSiteAlias.value.trim();

  if (!rawUrl) {
    showToast('Informe uma URL válida.');
    DOM.inputSiteUrl.focus();
    return;
  }

  const validation = SecurityAnalyzer.validateUrl(rawUrl);
  if (!validation.valid) {
    showToast(validation.error || 'URL com formato inválido.');
    return;
  }

  const analysis = SecurityAnalyzer.analyze(rawUrl);

  try {
    DOM.btnSaveSite.disabled = true;
    DOM.btnSaveSite.textContent = 'Cadastrando...';

    const newSite = await SitesStorage.add({
      url: validation.cleanUrl,
      alias: alias || validation.urlObj.hostname,
      riskLevel: analysis.level,
      riskLabel: analysis.label,
      riskDetails: analysis.reasons,
      status: 'checking'
    });

    // Registrar no histórico
    await HistoryStorage.addEntry({
      siteId: newSite.id,
      url: newSite.url,
      type: 'initial_check',
      message: `Domínio cadastrado para monitoramento com avaliação: ${analysis.label}.`,
      riskLevel: analysis.level,
      riskDetails: analysis.reasons
    });

    // Disparar checagem inicial imediata via Service Worker
    chrome.runtime.sendMessage({ action: 'CHECK_SINGLE_SITE', siteId: newSite.id }, async () => {
      await renderDashboard();
    });

    // Limpar formulário
    DOM.inputSiteUrl.value = '';
    DOM.inputSiteAlias.value = '';
    DOM.addSecurityPreview.style.display = 'none';

    showToast('Site cadastrado com sucesso!');

    // Alternar para a aba de Dashboard
    const dashboardTabBtn = document.querySelector('[data-tab="tab-dashboard"]');
    if (dashboardTabBtn) dashboardTabBtn.click();
  } catch (err) {
    showToast(err.message);
  } finally {
    DOM.btnSaveSite.disabled = false;
    DOM.btnSaveSite.textContent = 'Adicionar ao Monitoramento';
  }
}

/**
 * Renderiza o Dashboard com a lista de sites
 */
async function renderDashboard() {
  const sites = await SitesStorage.getAll();

  // Atualizar contadores
  const total = sites.length;
  const online = sites.filter(s => s.status === 'online').length;
  const offline = sites.filter(s => s.status === 'offline').length;

  DOM.statTotal.textContent = total;
  DOM.statOnline.textContent = online;
  DOM.statOffline.textContent = offline;

  DOM.sitesContainer.innerHTML = '';

  if (sites.length === 0) {
    DOM.sitesContainer.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🌐</div>
        <div class="empty-title">Nenhum site monitorado</div>
        <p>Cadastre uma URL na aba "Cadastrar" para iniciar o acompanhamento de disponibilidade e segurança.</p>
      </div>
    `;
    return;
  }

  sites.forEach(site => {
    const card = document.createElement('div');
    card.className = 'site-card';

    const statusBadgeClass = `badge ${site.status || 'unknown'}`;
    const statusText = site.status === 'online' ? 'Online' : (site.status === 'offline' ? 'Offline' : (site.status === 'checking' ? 'Checando...' : 'Pendente'));

    const riskBadgeClass = `badge badge-risk-${site.riskLevel || 'low'}`;
    const riskText = site.riskLabel || 'Nenhum risco conhecido';

    const responseTimeText = site.responseTimeMs !== null ? `${site.responseTimeMs}ms` : '--';
    const httpStatusText = site.httpStatus !== null ? `HTTP ${site.httpStatus}` : 'Sem resposta';
    const lastCheckedText = site.lastChecked ? formatTimeAgo(site.lastChecked) : 'Ainda não verificado';

    card.innerHTML = `
      <div class="site-card-top">
        <div class="site-info">
          <div class="site-alias" title="${site.alias}">${escapeHtml(site.alias)}</div>
          <div class="site-url" title="${site.url}">${escapeHtml(site.url)}</div>
        </div>
        <div class="site-badges">
          <span class="${riskBadgeClass}" title="Avaliação de Risco">${riskText}</span>
          <span class="${statusBadgeClass}">${statusText}</span>
        </div>
      </div>
      <div class="site-card-bottom">
        <div class="site-metrics">
          <span title="Código de Resposta">${httpStatusText}</span>
          <span>•</span>
          <span title="Latência / Tempo de Resposta">${responseTimeText}</span>
          <span>•</span>
          <span title="Última checagem">${lastCheckedText}</span>
        </div>
        <div class="site-actions">
          <button class="btn-mini btn-recheck" data-id="${site.id}" title="Re-testar conexão">Testar</button>
          <button class="btn-mini btn-details" data-id="${site.id}" title="Ver detalhes de segurança">Detalhes</button>
          <button class="btn-mini danger btn-delete" data-id="${site.id}" title="Remover monitoramento">Excluir</button>
        </div>
      </div>
    `;

    // Eventos dos Botões do Card
    card.querySelector('.btn-recheck').addEventListener('click', async () => {
      showToast(`Testando ${site.alias}...`);
      card.querySelector('.badge.online, .badge.offline, .badge.unknown').className = 'badge checking';
      card.querySelector('.badge.checking').textContent = 'Checando...';

      chrome.runtime.sendMessage({ action: 'CHECK_SINGLE_SITE', siteId: site.id }, async (response) => {
        if (response && response.success) {
          await renderDashboard();
          await renderHistory();
          showToast(`Concluído: ${site.alias} está ${response.site.status.toUpperCase()}`);
        } else {
          showToast('Falha no teste de conexão.');
        }
      });
    });

    card.querySelector('.btn-details').addEventListener('click', () => {
      openSiteDetailsModal(site);
    });

    card.querySelector('.btn-delete').addEventListener('click', async () => {
      if (confirm(`Deseja remover o monitoramento de "${site.alias}"?`)) {
        await SitesStorage.remove(site.id);
        await renderDashboard();
        showToast('Site removido com sucesso.');
      }
    });

    DOM.sitesContainer.appendChild(card);
  });
}

/**
 * Renderiza o Histórico de Ocorrências
 */
async function renderHistory() {
  const history = await HistoryStorage.getAll(50);
  DOM.historyContainer.innerHTML = '';

  if (history.length === 0) {
    DOM.historyContainer.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📜</div>
        <div class="empty-title">Nenhum evento registrado</div>
        <p>Alterações de disponibilidade, quedas de sites e análises de risco aparecerão aqui.</p>
      </div>
    `;
    return;
  }

  history.forEach(item => {
    const el = document.createElement('div');
    el.className = `history-item ${item.type}`;

    const dateFormatted = formatDateTime(item.timestamp);
    const badgeRisk = item.riskLevel ? `<span class="badge badge-risk-${item.riskLevel}">${item.riskLevel}</span>` : '';

    el.innerHTML = `
      <div class="history-header">
        <span class="history-url" title="${item.url}">${escapeHtml(item.url)}</span>
        <span class="history-time">${dateFormatted}</span>
      </div>
      <div class="history-msg">${escapeHtml(item.message)}</div>
    `;

    DOM.historyContainer.appendChild(el);
  });
}

/**
 * Executa Scanner Completo de URL na Aba Segurança
 */
function runFullScan(url) {
  const analysis = SecurityAnalyzer.analyze(url);
  DOM.scannerResultBox.style.display = 'flex';

  const riskBadgeClass = `badge badge-risk-${analysis.level}`;
  const details = analysis.details;

  let reasonsHtml = '';
  analysis.reasons.forEach(r => {
    reasonsHtml += `<li>${escapeHtml(r)}</li>`;
  });

  DOM.scannerResultBox.innerHTML = `
    <div class="security-preview-header">
      <span class="form-label" style="font-size: 13px;">Resultado da Avaliação</span>
      <span class="${riskBadgeClass}" style="font-size: 11px;">${analysis.label}</span>
    </div>

    <div style="font-size: 11.5px; color: var(--text-muted); line-height: 1.5; margin-top: 4px;">
      <strong>Score de Risco:</strong> ${analysis.score}/100<br/>
      <strong>Protocolo:</strong> ${details.isHttps ? 'HTTPS (Criptografado)' : 'HTTP (Inseguro)'}<br/>
      <strong>Entropia do SLD:</strong> ${details.entropy} bits<br/>
      <strong>Subdomínios:</strong> ${details.subdomainCount} nível(is)<br/>
      <strong>Uso de Punycode (IDN):</strong> ${details.isPunycode ? 'Sim' : 'Não'}<br/>
      <strong>IP Literal:</strong> ${details.isIpAddress ? 'Sim' : 'Não'}
    </div>

    <div style="margin-top: 8px;">
      <span class="form-label" style="font-size: 11.5px;">Fatores Identificados:</span>
      <ul class="security-reasons-list" style="margin-top: 4px;">
        ${reasonsHtml}
      </ul>
    </div>
  `;
}

/**
 * Abre modal com detalhes detalhados do site
 */
function openSiteDetailsModal(site) {
  DOM.modalSiteTitle.textContent = site.alias || site.hostname;

  let detailsHtml = `
    <div style="display: flex; flex-direction: column; gap: 8px; font-size: 12px;">
      <div><strong>URL:</strong> <span style="word-break: break-all;">${escapeHtml(site.url)}</span></div>
      <div><strong>Status Atual:</strong> <span class="badge ${site.status}">${site.status ? site.status.toUpperCase() : 'UNKNOWN'}</span></div>
      <div><strong>Código HTTP:</strong> ${site.httpStatus !== null ? site.httpStatus : 'Sem resposta'}</div>
      <div><strong>Latência de Resposta:</strong> ${site.responseTimeMs !== null ? site.responseTimeMs + ' ms' : '--'}</div>
      <div><strong>Cadastrado em:</strong> ${formatDateTime(site.addedAt)}</div>
      <div><strong>Última Verificação:</strong> ${site.lastChecked ? formatDateTime(site.lastChecked) : 'Nunca'}</div>
      
      <hr style="border: 0; border-top: 1px solid var(--border-color); margin: 6px 0;"/>
      
      <div><strong>Avaliação de Segurança:</strong> <span class="badge badge-risk-${site.riskLevel}">${site.riskLabel}</span></div>
      <div><strong>Indicadores de Risco:</strong></div>
      <ul class="security-reasons-list">
  `;

  if (site.riskDetails && site.riskDetails.length > 0) {
    site.riskDetails.forEach(d => {
      detailsHtml += `<li>${escapeHtml(d)}</li>`;
    });
  } else {
    detailsHtml += `<li>Nenhum fator suspeito detectado na estrutura do domínio.</li>`;
  }

  detailsHtml += `
      </ul>
    </div>
  `;

  DOM.modalSiteBody.innerHTML = detailsHtml;
  DOM.siteModal.classList.add('show');
}

/**
 * Utilitário de Toast
 */
function showToast(message) {
  DOM.toast.textContent = message;
  DOM.toast.classList.add('show');
  setTimeout(() => {
    DOM.toast.classList.remove('show');
  }, 2600);
}

/**
 * Formatação amigável de tempo relativo
 */
function formatTimeAgo(isoString) {
  try {
    const diff = Math.floor((Date.now() - new Date(isoString).getTime()) / 1000);
    if (diff < 10) return 'Agora mesmo';
    if (diff < 60) return `${diff}s atrás`;
    const mins = Math.floor(diff / 60);
    if (mins < 60) return `${mins}m atrás`;
    const hours = Math.floor(mins / 60);
    return `${hours}h atrás`;
  } catch {
    return 'Recentemente';
  }
}

/**
 * Formatação de Data e Hora
 */
function formatDateTime(isoString) {
  if (!isoString) return '--';
  try {
    const d = new Date(isoString);
    return d.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  } catch {
    return isoString;
  }
}

/**
 * Sanitização básica de HTML
 */
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
