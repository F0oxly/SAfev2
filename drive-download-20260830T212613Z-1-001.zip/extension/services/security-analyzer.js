/**
 * SafeWeb - Security & Risk Analyzer
 * Módulo heurístico de análise de risco e reputação de URLs.
 * 
 * Regra fundamental: NUNCA afirmar que um site é 100% seguro.
 * Classificações adotadas:
 * - "Nenhum risco conhecido" (baixo risco detectado)
 * - "Atenção" (anomalias ou padrões incomuns)
 * - "Possível ameaça" (múltiplos fatores de risco crítico)
 */

export class SecurityAnalyzer {
  // Lista de TLDs com alta taxa histórica de abuso/phishing
  static SUSPICIOUS_TLDS = [
    '.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top', '.work', 
    '.click', '.loan', '.zip', '.mov', '.surf', '.cam', '.fit'
  ];

  // Palavras-chave comumente usadas em campanhas de engenharia social
  static PHISHING_KEYWORDS = [
    'login', 'signin', 'verify', 'verification', 'update-account',
    'secure-account', 'banking', 'recovery', 'auth-check', 'confirm-identity',
    'wallet', 'redefinir', 'recuperar-conta', 'atualizacao', 'seguranca'
  ];

  /**
   * Valida sintaticamente uma URL
   * @param {string} inputUrl 
   * @returns {{ valid: boolean, error?: string, urlObj?: URL }}
   */
  static validateUrl(inputUrl) {
    if (!inputUrl || typeof inputUrl !== 'string') {
      return { valid: false, error: 'URL não pode ser vazia.' };
    }

    let urlToParse = inputUrl.trim();
    if (!/^https?:\/\//i.test(urlToParse)) {
      urlToParse = 'https://' + urlToParse;
    }

    try {
      const parsed = new URL(urlToParse);
      
      if (!parsed.hostname || parsed.hostname.length < 3) {
        return { valid: false, error: 'Domínio ou hostname inválido.' };
      }

      // Validação básica de formato de hostname
      const hostnamePattern = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$|^localhost$|^(\d{1,3}\.){3}\d{1,3}$/;
      if (!hostnamePattern.test(parsed.hostname) && !parsed.hostname.startsWith('xn--')) {
        return { valid: false, error: 'Formato de domínio não reconhecido.' };
      }

      return { valid: true, urlObj: parsed, cleanUrl: parsed.origin + (parsed.pathname !== '/' ? parsed.pathname : '') };
    } catch {
      return { valid: false, error: 'A URL informada possui formato inválido.' };
    }
  }

  /**
   * Calcula a entropia de Shannon de uma string (detecção de DGAs / domínios aleatórios)
   * @param {string} str 
   * @returns {number}
   */
  static calculateEntropy(str) {
    if (!str) return 0;
    const len = str.length;
    const frequencies = {};

    for (let i = 0; i < len; i++) {
      const char = str[i];
      frequencies[char] = (frequencies[char] || 0) + 1;
    }

    let entropy = 0;
    for (const char in frequencies) {
      const p = frequencies[char] / len;
      entropy -= p * Math.log2(p);
    }

    return entropy;
  }

  /**
   * Executa a análise heurística de segurança e risco da URL
   * @param {string} targetUrl 
   * @returns {Object} Resultado estruturado da análise
   */
  static analyze(targetUrl) {
    const validation = this.validateUrl(targetUrl);
    if (!validation.valid || !validation.urlObj) {
      return {
        level: 'high',
        label: 'Possível ameaça',
        score: 90,
        reasons: ['URL com estrutura malformada ou inválida.'],
        details: { flags: ['invalid_format'] }
      };
    }

    const url = validation.urlObj;
    const hostname = url.hostname.toLowerCase();
    const pathname = url.pathname.toLowerCase();
    const fullHref = url.href.toLowerCase();

    let score = 0; // 0 (sem riscos aparentes) a 100 (risco muito alto)
    const reasons = [];
    const flags = [];

    // 1. Verificação de Protocolo (HTTPS vs HTTP)
    const isHttps = url.protocol === 'https:';
    if (!isHttps && hostname !== 'localhost' && hostname !== '127.0.0.1') {
      score += 25;
      flags.push('no_https');
      reasons.push('Conexão não criptografada (HTTP). Dados trafegam em texto claro.');
    }

    // 2. Verificação de Endereço IP Direto
    const isIpAddress = /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname);
    if (isIpAddress && hostname !== '127.0.0.1') {
      score += 35;
      flags.push('ip_hostname');
      reasons.push('Uso de endereço IP direto no lugar de um nome de domínio registrado.');
    }

    // 3. Detecção de Homografia / Punycode (IDN attacks)
    const isPunycode = hostname.startsWith('xn--') || hostname.includes('.xn--');
    if (isPunycode) {
      score += 30;
      flags.push('punycode_domain');
      reasons.push('Domínio utiliza codificação Punycode (IDN), comumente associado a ataques de homografia (imitação de caracteres).');
    }

    // 4. Verificação de TLDs com histórico suspeito
    const matchedTld = this.SUSPICIOUS_TLDS.find(tld => hostname.endsWith(tld));
    if (matchedTld) {
      score += 20;
      flags.push('suspicious_tld');
      reasons.push(`Uso de extensão de domínio comumente explorada para abusos (${matchedTld}).`);
    }

    // 5. Contagem excessiva de Subdomínios (técnica de mascaramento)
    const parts = hostname.split('.');
    const subdomainCount = Math.max(0, parts.length - 2);
    if (subdomainCount >= 3) {
      score += 20;
      flags.push('excessive_subdomains');
      reasons.push(`Estrutura profunda de subdomínios detectada (${subdomainCount} níveis).`);
    }

    // 6. Palavras-chave suspeitas em domínios ou subdomínios
    const foundKeywords = this.PHISHING_KEYWORDS.filter(kw => fullHref.includes(kw));
    if (foundKeywords.length > 0 && !this.isKnownTrustedDomain(hostname)) {
      score += foundKeywords.length * 15;
      flags.push('phishing_keywords');
      reasons.push(`Presença de termos sensíveis (${foundKeywords.slice(0, 3).join(', ')}) em domínio não reconhecido.`);
    }

    // 7. Número excessivo de hífens no hostname (ex: login-update-myaccount-bank.com)
    const hyphenCount = (hostname.match(/-/g) || []).length;
    if (hyphenCount >= 3) {
      score += 15;
      flags.push('excessive_hyphens');
      reasons.push(`Hostname contém múltiplos hífens (${hyphenCount}), comum em domínios de engenharia social.`);
    }

    // 8. Entropia do domínio (DGA / Domínios gerados aleatoriamente)
    const sld = parts.length >= 2 ? parts[parts.length - 2] : parts[0];
    const entropy = this.calculateEntropy(sld);
    if (sld.length > 10 && entropy > 3.8) {
      score += 20;
      flags.push('high_entropy');
      reasons.push('Nome do domínio possui alta entropia aleatória (possível geração algorítmica).');
    }

    // 9. Uso de porta não padrão
    if (url.port && !['80', '443', '3000', '8080'].includes(url.port)) {
      score += 10;
      flags.push('non_standard_port');
      reasons.push(`Conexão utilizando porta não convencional (:${url.port}).`);
    }

    // Determinação dos Níveis Acadêmicos Exigidos
    let level = 'low';
    let label = 'Nenhum risco conhecido';

    if (score >= 50) {
      level = 'high';
      label = 'Possível ameaça';
    } else if (score >= 20) {
      level = 'attention';
      label = 'Atenção';
    } else {
      level = 'low';
      label = 'Nenhum risco conhecido';
      if (reasons.length === 0) {
        reasons.push('Estrutura de URL padrão com protocolo seguro e sem indicadores suspeitos conhecidos.');
      }
    }

    return {
      level,
      label,
      score: Math.min(score, 100),
      reasons,
      details: {
        protocol: url.protocol,
        isHttps,
        isIpAddress,
        isPunycode,
        subdomainCount,
        entropy: parseFloat(entropy.toFixed(2)),
        flags
      }
    };
  }

  /**
   * Auxiliar para checar se o hostname é um dos serviços comuns consolidados
   * @param {string} hostname 
   * @returns {boolean}
   */
  static isKnownTrustedDomain(hostname) {
    const trusted = [
      'google.com', 'github.com', 'microsoft.com', 'apple.com', 
      'wikipedia.org', 'mozilla.org', 'cloudflare.com', 'usp.br',
      'unicamp.br', 'ufrj.br', 'gov.br'
    ];
    return trusted.some(t => hostname === t || hostname.endsWith('.' + t));
  }
}
