/**
 * SafeWeb - API Client
 * Cliente de comunicação com o backend em Node.js (com fallback gracioso)
 */

import { StorageManager } from '../storage/storage-manager.js';

export class ApiClient {
  /**
   * Obtém a URL base configurada para o backend
   */
  static async getBaseUrl() {
    const config = await StorageManager.getConfig();
    return config.backendUrl || 'http://localhost:3000';
  }

  /**
   * Verifica se o backend Node.js está online e respondendo
   * @returns {Promise<boolean>}
   */
  static async isBackendAvailable() {
    try {
      const baseUrl = await this.getBaseUrl();
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);

      const response = await fetch(`${baseUrl}/api/health`, {
        method: 'GET',
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * Solicita verificação de status de um site ao backend
   * @param {string} url 
   * @returns {Promise<Object|null>}
   */
  static async checkSite(url) {
    try {
      const baseUrl = await this.getBaseUrl();
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const response = await fetch(`${baseUrl}/api/sites/check`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Backend retornou código HTTP ${response.status}`);
      }

      return await response.json();
    } catch (err) {
      console.warn(`[SafeWeb ApiClient] Falha ao consultar backend para ${url}:`, err.message);
      return null;
    }
  }

  /**
   * Sincroniza a lista de sites cadastrados com o backend
   * @param {Array} sites 
   * @returns {Promise<boolean>}
   */
  static async syncSites(sites) {
    try {
      const baseUrl = await this.getBaseUrl();
      const response = await fetch(`${baseUrl}/api/sites/sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sites })
      });
      return response.ok;
    } catch {
      return false;
    }
  }
}
