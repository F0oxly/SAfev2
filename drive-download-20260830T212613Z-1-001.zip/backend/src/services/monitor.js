/**
 * SafeWeb - Backend Monitor Service
 * Serviço de checagem contínua de disponibilidade e testes HTTP
 */

export class MonitorService {
  constructor() {
    this.sites = new Map();
    this.history = [];
    this.timer = null;
    this.intervalSeconds = 60;
  }

  /**
   * Inicia o loop de monitoramento contínuo em segundo plano
   * @param {number} intervalSeconds 
   */
  start(intervalSeconds = 60) {
    this.intervalSeconds = intervalSeconds;
    if (this.timer) clearInterval(this.timer);

    console.log(`[SafeWeb Backend] Monitor iniciado. Intervalo de checagem: ${intervalSeconds}s.`);
    
    // Execução periódica
    this.timer = setInterval(async () => {
      await this.checkAll();
    }, this.intervalSeconds * 1000);
  }

  /**
   * Para o loop do monitor
   */
  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      console.log('[SafeWeb Backend] Monitor pausado.');
    }
  }

  /**
   * Realiza teste de conexão e tempo de resposta em uma URL
   * @param {string} url 
   * @param {number} timeoutMs 
   * @returns {Promise<Object>}
   */
  async checkUrl(url, timeoutMs = 6000) {
    const startTime = Date.now();
    let isOnline = false;
    let httpStatus = null;
    let errorMessage = null;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      // Requisição HEAD inicial
      let response;
      try {
        response = await fetch(url, {
          method: 'HEAD',
          signal: controller.signal,
          headers: {
            'User-Agent': 'SafeWeb-Uptime-Bot/1.0 (+https://github.com/safeweb)'
          }
        });
      } catch (e) {
        // Se HEAD falhar por método não permitido (405) ou similar, tenta GET
        response = await fetch(url, {
          method: 'GET',
          signal: controller.signal,
          headers: {
            'User-Agent': 'SafeWeb-Uptime-Bot/1.0 (+https://github.com/safeweb)'
          }
        });
      }

      clearTimeout(timeoutId);
      httpStatus = response.status;
      // Consideramos online se retornar códigos 2xx ou 3xx
      isOnline = response.status >= 200 && response.status < 400;

      if (!isOnline) {
        errorMessage = `Servidor respondeu com código de erro HTTP ${response.status}`;
      }
    } catch (err) {
      isOnline = false;
      httpStatus = null;
      if (err.name === 'AbortError') {
        errorMessage = `Tempo limite esgotado (${timeoutMs}ms)`;
      } else {
        errorMessage = err.message || 'Falha de conexão / DNS';
      }
    }

    const responseTimeMs = Date.now() - startTime;

    return {
      checked: true,
      url,
      status: isOnline ? 'online' : 'offline',
      httpStatus,
      responseTimeMs,
      error: errorMessage,
      checkedAt: new Date().toISOString()
    };
  }

  /**
   * Executa a checagem em todos os sites cadastrados no backend
   */
  async checkAll() {
    const siteList = Array.from(this.sites.values());
    if (siteList.length === 0) return [];

    console.log(`[SafeWeb Backend] Verificando ${siteList.length} site(s)...`);

    for (const site of siteList) {
      const previousStatus = site.status;
      const result = await this.checkUrl(site.url);

      const newStatus = result.status;
      site.status = newStatus;
      site.httpStatus = result.httpStatus;
      site.responseTimeMs = result.responseTimeMs;
      site.lastChecked = result.checkedAt;

      // Detectar mudança de estado
      if (previousStatus && previousStatus !== 'unknown' && previousStatus !== newStatus) {
        site.lastStatusChange = result.checkedAt;

        const eventEntry = {
          id: 'be_evt_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
          siteId: site.id,
          url: site.url,
          timestamp: result.checkedAt,
          type: newStatus === 'online' ? 'recovery' : 'status_change',
          message: newStatus === 'online'
            ? `Site recuperado (${result.responseTimeMs}ms, HTTP ${result.httpStatus || 200})`
            : `Site indisponível (${result.error || 'HTTP ' + result.httpStatus})`,
          httpStatus: result.httpStatus,
          responseTimeMs: result.responseTimeMs,
          previousStatus,
          newStatus
        };

        this.addHistory(eventEntry);
        console.warn(`[SafeWeb Alerta] Status de ${site.url} alterado: ${previousStatus} -> ${newStatus}`);
      }

      this.sites.set(site.id, site);
    }

    return Array.from(this.sites.values());
  }

  /**
   * Adiciona registro ao histórico
   */
  addHistory(entry) {
    this.history.unshift(entry);
    if (this.history.length > 200) {
      this.history.pop();
    }
  }

  /**
   * Sincroniza a lista de sites recebida da extensão
   * @param {Array} extensionSites 
   */
  syncSites(extensionSites) {
    if (!Array.isArray(extensionSites)) return;
    
    // Atualiza ou insere sites
    for (const s of extensionSites) {
      if (!s.id || !s.url) continue;
      const existing = this.sites.get(s.id);
      this.sites.set(s.id, {
        ...s,
        ...(existing || {})
      });
    }

    // Remove sites que foram deletados na extensão
    const incomingIds = new Set(extensionSites.map(s => s.id));
    for (const [id] of this.sites) {
      if (!incomingIds.has(id)) {
        this.sites.delete(id);
      }
    }
  }
}

export const monitorService = new MonitorService();
