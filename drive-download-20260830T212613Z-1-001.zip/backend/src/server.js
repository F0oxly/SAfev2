/**
 * SafeWeb - Backend Server
 * Servidor Express com suporte a CORS, health checks e inicialização do Monitor Service.
 */

import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import sitesRouter from './routes/sites.js';
import historyRouter from './routes/history.js';
import securityRouter from './routes/security.js';
import { monitorService } from './services/monitor.js';

const app = express();
const PORT = process.env.PORT || 3000;
const MONITOR_INTERVAL = parseInt(process.env.MONITOR_INTERVAL_SECONDS || '60', 10);

// Middlewares
app.use(cors({
  origin: '*', // Permite requisições da extensão Chrome
  methods: ['GET', 'POST', 'DELETE', 'PUT', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Endpoint de Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'SafeWeb Backend',
    version: '1.0.0',
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString()
  });
});

// Rotas da API
app.use('/api/sites', sitesRouter);
app.use('/api/history', historyRouter);
app.use('/api/security', securityRouter);

// Tratamento de Rota Não Encontrada
app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Endpoint não encontrado.' });
});

// Inicialização do Servidor
app.listen(PORT, () => {
  console.log(`=========================================`);
  console.log(`🛡️  SafeWeb Backend ativo na porta ${PORT}`);
  console.log(`🌐 Health check: http://localhost:${PORT}/api/health`);
  console.log(`=========================================`);

  // Iniciar serviço de monitoramento contínuo
  monitorService.start(MONITOR_INTERVAL);
});
